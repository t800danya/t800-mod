T-800 Mod is made by 
Bogdan Kozyrev
Uchenik Shkoly N3 im Abaya
g Talgaг, Alamaty Oblast, Kazhakhstan
contacty: t800@kvkozyrev.org
http://wiki.kvkozyrev.org/

