
                 
Map Name:	  Dark Citadel - Darkc.mx2

Map Maker:	  Rade & Milan

E-Mail Address:	  milord@mailcity.com

Map Type:	  multiplayer, also can be played as a singleplayer
		  1 Computer only, 5 Humans or Computer

Description:	  Defeat the necromansers of the Dark Citadel

Special Win:	  Capture a castle Dark Citadel

Special Loss:	  None

Special Other:	  Maybe is the best for playing Cooperative (hotseat)
	
Completely
Play-Tested:	  Yes many, many, many times (hours, days, years)!

Narrative:        Many resources, many treasures, many artefacts.
		  If you are a lover of a good and healthy playing, 
		  then you will love it! Playing this map, can
		  seriously damage your health, and cause the lack of sleep.


Hint: 		  There is a prison near every castle, that will aid you in the start.
		  Don't attack the necromansers, if you are not prepared, and i mean
		  real prepared! This map can be played very fast, or may be played
		  for years. It's on you to choose :)