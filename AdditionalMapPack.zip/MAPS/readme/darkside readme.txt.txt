Here is a new map file for Heroes of Might and Magic II.

Creator: Matt Hussung of Rockford, IL
Create Time: 10 Hours
Size: XL
Difficulty: Medium-Hard

Story: You are a rare breed, a necromancer of good. Evil warlocks from the castle Darkside
       have slain most of your family, threatened your townspeople, and taken your lady.
       You must lay siege upon castle Darkside and destroy it. This note your average 
       search and destroy mission. You will be helped along the way by the good wizard 
       Merlin. You may visit the Castle of Camelot and King Arthur. Fight your way through
       "the arena." There are many secret messages and an elaborate storyline that will
       unfold. I hope you enjoy playing it as I did creating it. Good Luck!
